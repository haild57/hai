#include <iostream> 
#include <windows.h>	
using namespace std; 

int main() 
{ 
	int year_now, month_now, age_now, month_borned, another_year, another_month, another_age; 
	int year_borned, month_old;
	 
	cout << "Enter the current year then press Enter key.\n"; 
	cin >> year_now; 
	
	cout<<"Enter the current month then press Enter key.\n";
	cin>>month_now;
	
	cout << "Enter your current age in years.\n"; 
	cin >> age_now; 
	
	cout<<"Enter the month in which you were born (a number from 1 to 12):";
	cin>>month_borned;

	 
	cout << "Enter the year for which you wish to know your age.\n";
	cin >> another_year; 

	cout<<"Enter the month in the year above here:";	 
	cin>>another_month;
	
	another_age = another_year - year_now + age_now;
	month_old = another_month - month_borned;
	if(another_month<0){
		another_age = another_age - 1;
		month_old = month_old + 12;
	}
	
	if (another_age >= 0&&another_age<=150) {
		cout << "Your age in " <<another_month<<"/"<< another_year << ": "; 
		cout << another_age <<" and "<<month_old<<" month"<<"\n";
	}else if(another_age>150){
		cout<<"Sorry, but you'll probably be dead by [year]!"<<endl;
	}else { 
		cout << "You weren't even born in ";
		cout << another_year << "!\n"; 
	}
	system("pause");
	return 0; 
}

