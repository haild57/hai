#include<iostream>
#include<iomanip>
using namespace std;
void inputTem(float & lower, float &upper, float &step);
void printExplain();
void printEcho(float & lower, float &upper, float &step);
void printTable(float & lower, float &upper, float &step);
main(void)
{
	float lower, upper, step;
	printExplain();
	inputTem(lower, upper, step);
	printEcho(lower, upper, step);
	printTable(lower, upper, step);
}
void inputTem(float & lower, float &upper, float &step){
	cout<<"nhap vao nhiet do san: ";
	cin>> lower;
	cout<<"nhap vao nhiet do tran: ";
	cin>>upper;
	cout<<"nhap vao khoang cach ban muon: ";
	cin>>step;
}
void printExplain(){
	cout<<" \nchuong trinh in ra bang chuyen doi nhiet do\n sau khi da nhac nguoi dung nhap nhiet do \n thap hon cao hon trong thang fahrenheit \n";
	cout<<" va cac bang nhiet do khac\n";
}
void printEcho(float & lower, float &upper, float &step){
	cout<<"ban vua nhap nhiet do thap la : "<< lower;
	cout<<"nhiet do cao hon la: "<<upper;
	cout<<"khoang cach trong bang: "<<step;
}
void printTable(float & min_fah, float &max_fah, float &space){
	float abs, cel;
	cout<<setw(10)<<"fahrenheit";
	cout<<setw(15)<<"absolute";
	cout<<setw(20)<<"celcius"<<endl;
	for(float min_fah = 0;min_fah<=max_fah;min_fah= min_fah + space){
		cel = (min_fah-32)*5/9;
		abs = cel + 273.15;
		cout<<setw(20)<<setprecision(5)<<left<<min_fah;
		cout<<setw(20)<<setprecision(5)<<left<<cel;
		cout<<setw(20)<<setprecision(5)<<left<<abs<<endl;
	}
}
