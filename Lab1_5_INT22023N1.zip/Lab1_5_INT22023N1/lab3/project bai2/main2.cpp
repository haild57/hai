#include <iostream>
#include <iomanip>
#include <windows.h>
using namespace std;
#include "header2.h"
#include "funtion.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main() {
	float lower, upper, step;
	printExplain();
	inputTem(lower, upper, step);
	printEcho(lower, upper, step);
	printTable(lower, upper, step);
	system("pause");
	return 0;
}


