void inputTem(float & lower, float &upper, float &step);
void printExplain();
void printEcho(float & lower, float &upper, float &step);
void printTable(float & lower, float &upper, float &step);
