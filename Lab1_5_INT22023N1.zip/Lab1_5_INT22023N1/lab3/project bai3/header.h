float standard_deviation(float a, float b, float c, float d,int times,float aver);
void average(int times);
