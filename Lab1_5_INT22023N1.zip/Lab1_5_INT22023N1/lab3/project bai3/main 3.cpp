#include <iostream>
#include <cmath>
using namespace std;
#include "header.h"
#include "statistics.h"
main (void)
{
	int i = 0;
	while(1){
		cout<<"\nban muon tinh 1, 2, 3 hay 4 so:"<<endl;
		cout<<"bam so muon neu bam 0 la thoat."<<endl;
		cin>>i;
		if(i == 0) break;
		else if((i>0)&&(i<5)){
			 average(i);
		}
		else cout<<" chi co the tinh tu mot den 4 so";
		i = 0;
	}
}
