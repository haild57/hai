void average(int times)
{
	float a =0,b = 0, c  =0, d =0, aver;
	if( times == 1){
		cout<<"nhap gia tri so thu nhat:";
		cin>>a;
	}
	if(times == 2){
		cout<<"nhap gia tri so thu nhat:";
		cin>>a;
		cout<<"nhap gia tri so thu hai:";
		cin>>b;
	}
	if(times == 3){
		cout<<"nhap gia tri so thu nhat:";
		cin>>a;
		cout<<"nhap gia tri so thu hai:";
		cin>>b;
		cout<<"nhap gia tri so thu ba:";
		cin>>c;
	}
	if(times == 4){
		cout<<"nhap gia tri so thu nhat:";
		cin>>a;
		cout<<"nhap gia tri so thu hai:";
		cin>>b;
		cout<<"nhap gia tri so thu ba:";
		cin>>c;
		cout<<"nhap gia tri so thu tu:";
		cin>>d;
	}
	aver = (a + b + c + d)/4;
	cout<<"trung binh:"<<aver<<endl;
	cout<<"do lech chuan: "<<standard_deviation(a,b,c,d,times,aver);
}
float standard_deviation(float a, float b, float c, float d,int times,float aver)
{
	float stdv, dem;
	if(times == 1){ 
		stdv  = 0;
	}else
	if(times == 2){
		dem = (a -aver)*(a -aver) + (b -aver)*(b -aver);
		stdv = sqrt(dem);
	}else
	if(times == 3){
		dem = (a -aver)*(a -aver) + (b -aver)*(b -aver) + (c -aver)*(c -aver);
		stdv = sqrt(dem);
	}else 
	if(times == 4){
		dem = (a -aver)*(a -aver) + (b -aver)*(b -aver) + (c -aver)*(c -aver) + (d -aver)*(d -aver);
		stdv = sqrt(dem);
	}
	return stdv;
}
