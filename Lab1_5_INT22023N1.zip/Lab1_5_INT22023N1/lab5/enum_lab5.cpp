#include<iostream>
#include<iomanip>
//chuminhuet@gmail.com
using namespace std;
enum Day {chunhat,thu2,thu3,thu4,thu5, thu6, thu7};
int ngay_thang(int a);
void inlich(Day thu);
bool ngoaiLe(int i,int j);
main(void)
{
	cout.setf(ios::left);
	int i = 0, j = 0;//i thang, h
	//int nga,tha,nam;
	int h_ng,h_th,h_thu;//ngay hien tai, thang hien tai, thu hien tai
	int t_ng,t_th;//ngay tuong lai, thang tuong lai;
	
	cout<<"nhap ngay hien tai : ";
	cin >>h_ng;
	cout<<"nhap thang hien tai: ";
	cin>>h_th;
	cout<<"nhap thu hien tai: ";
	cin>>h_thu;
	cout<<"nhap ngay tuong lai: ";
	cin>>t_ng;
	cout<<"nhap thang tuong lai: ";
	cin>>t_th;
	cout<<"thu nghiem: "<<static_cast<int>(thu7)<<endl;
	for( i = h_th;i <= t_th;i++){
		if(i == h_th){
			j = h_ng;
		}else j = 1;
		for(;j<= ngay_thang(i);j++){
			//cout.width(15);
			cout<<"NGAY: "<<setw(5)<<left<<j;
			cout<<" THANG: "<<setw(5)<<left<<i<<" NAM:"<<" 2014";
			//cout.width(40);
			h_thu++;
			cout<<h_thu;
			if(ngoaiLe(i,j)){
				cout<<"		THI HOC KY BINH THUONG";
			}else {
				inlich(static_cast<Day>(h_thu));
			}
			cout<<endl<<endl;
			if(h_thu <7){
				h_thu=0;
			}
			
			if(i == t_th && j == t_ng){
				break;
			}
		}
	}
	
}
int ngay_thang(int a){
	switch(a){
		case 1: return 31; break;
		case 3: return 31; break;
		case 5: return 31; break;
		case 7: return 31; break;
		case 8: return 31; break;
		case 10: return 31; break;
		case 12: return 31; break;
		case 4: return 30; break;
		case 6: return 30; break;
		case 9: return 30; break;
		case 11: return 30; break;
		default: return 28;
	}
}
void inlich(Day thu){
	//cout.width(10);
	switch(thu){
		case chunhat: cout<<"		Chu nhat nghi hoc binh thuong"; break;
		case thu2: cout<<"		Thu 2 hoc binh thuong"; break;
		case thu3: cout<<"		Thu 3 hoc binh thuong"; break;
		case thu4: cout<<"		Thu 4 hoc binh thuong"; break;
		case thu5: cout<<"		Thu 5 hoc binh thuong"; break;
		case thu6: cout<<"		Thu 6 hoc binh thuong"; break;
		case thu7: cout<<"		Thu 7 nghi hoc binh thuong"; break;
	}
}
bool ngoaiLe(int i, int j){
	if(i == 5&& j == 7) return true;
	else if(i == 5 && j == 10) return true;
	else return false;
}
