#include<iostream>
#include<iostream>
#include<fstream>
using namespace std;
main(void){
	fstream out("pyramid.txt");
	int i = 1,j = 1;
	int n = 6, ch = n;
	for(i = 1;i<=n;i++){
		ch = ch +1;
		for(j = 1;j<=ch;j++){
			if(j<=(ch - 2*i)){
				cout<<" ";
				out<<" ";
			}else{
				cout<<"*";
				out<<"*";
				}
		}
		cout<<endl;
		out<<"\n";
	}
	out.close();
}
