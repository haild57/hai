#include<iostream>
#include<conio.h>
#include<windows.h>
using namespace std;
main(void)
{
	char c;
	int ord = 0;
	cout<<"nhap ki tu tu ban phim: ";
	c = getch();
	cout<<c<<endl;
	ord = c;
	if(ord<=122&&ord>=97){
		ord = ord -32;
		c = ord;
		cout<<endl<<c;
	}else if(ord>=65&&ord<=90){
		ord = ord + 32;
		c= ord;
		cout<<endl<<c;
	}else cout<<"\nday ban nhap khong thuoc ky tu de ghi";
	system("pause");//a=97 z = 122 A=65 =90
}
