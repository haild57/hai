#include<conio.h>
#include<iostream>
#include<iomanip>
using namespace std;

main(void)
{
	float abs, cel, min_fah, max_fah;
	float space;
	cout<<"nhap nhiet do thap nhat:";
	cin>>min_fah;
	cout<<"nhap vao nhiet do cao nhat:";
	cin>>max_fah;
	cout<<"nhap khoang cach:";
	cin>>space;
	cout<<setw(10)<<"fahrenheit";
	cout<<setw(15)<<"absolute";
	cout<<setw(23)<<"celcius"<<endl;
	for(float min_fah = 0;min_fah<=max_fah;min_fah= min_fah + space){
		cel = (min_fah-32)*5/9;
		abs = cel + 273.15;
		cout<<setw(20)<<setprecision(5)<<left<<min_fah;
		cout<<setw(20)<<setprecision(5)<<left<<cel;
		cout<<setw(20)<<setprecision(5)<<left<<abs<<endl;
	}
}
