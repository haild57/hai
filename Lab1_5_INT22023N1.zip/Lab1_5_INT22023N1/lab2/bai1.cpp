#include<conio.h>
#include<iostream>
#include<iomanip>
using namespace std;

main(void)
{
	float abs, cel, fah =0;
	cout<<setw(10)<<"fahrenheit";
	cout<<setw(15)<<"absolute";
	cout<<setw(10)<<"celcius"<<endl;
	for(float fah = 0;fah<=300;fah= fah + 20){
		cel = (fah-32)*5/9;
		abs = cel + 273.15;
		cout<<setw(20)<<setprecision(5)<<left<<fah;
		cout<<setw(20)<<setprecision(5)<<left<<cel;
		cout<<setw(20)<<setprecision(5)<<left<<abs<<endl;
	}
	getch();
}
