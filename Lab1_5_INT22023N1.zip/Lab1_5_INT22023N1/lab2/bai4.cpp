#include<iostream>
#include<conio.h>
using namespace std;
main(void){
	float so = 0;
	int mu = 0;
	cout<<"nhap so duong ban can tinh: ";
	cin>>so;
	float res = 1;
	cout<<"nhap so mu them vao: ";
	cin>>mu;
	for(int i  = 0; i < mu; i++ ){
		res = res*so;
	}
	cout<<"ket qua: "<<res;
	getch();
}
