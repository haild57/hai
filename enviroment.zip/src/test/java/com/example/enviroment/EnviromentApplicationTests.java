package com.example.enviroment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnviromentApplicationTests {

	@Test
	void contextLoads() {
	}

}
