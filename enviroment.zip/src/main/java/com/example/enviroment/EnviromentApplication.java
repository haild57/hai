package com.example.enviroment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnviromentApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(EnviromentApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Logger logger = LoggerFactory.getLogger(EnviromentApplication.class);
		// System.out.println(System.getenv());
		String inpuString = System.getenv("BatchInput");
		// System.out.println("inputString:");	
		// System.out.println(inpuString);
		logger.info("BatchInput["+ inpuString + "]");
	}

}
