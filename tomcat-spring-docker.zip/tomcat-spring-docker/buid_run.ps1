docker rm -f $(docker ps -q)
docker image rm -f stepfunction
mvn clean
mvn clean install
mvn install
docker build -t multi-output .
docker tag multi-output hai10101992/stepfunction:multi-output
docker push hai10101992/stepfunction:multi-output
docker-compose up
