docker rm -f $(docker ps -q)
docker image rm -f ribs
mvn clean
mvn install
docker build -t ribs .
docker tag ribs hai10101992/apigateway-cognito-handson:ribsv6
docker push hai10101992/apigateway-cognito-handson:ribsv6

# docker-compose up