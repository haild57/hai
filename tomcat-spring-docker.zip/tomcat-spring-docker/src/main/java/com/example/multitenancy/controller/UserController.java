package com.example.multitenancy.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("user")
public class UserController {

    @GetMapping("/")
    public String international(ModelMap modelMap, HttpSession httpSession) {
        modelMap.addAttribute("accessToken", (String) httpSession.getAttribute("accessToken"));
        modelMap.addAttribute("idToken", (String) httpSession.getAttribute("idToken"));
        modelMap.addAttribute("refreshToken", (String) httpSession.getAttribute("refreshToken"));
        return "international";
    }
}
