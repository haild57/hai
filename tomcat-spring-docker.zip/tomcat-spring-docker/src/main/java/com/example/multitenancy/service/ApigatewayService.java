package com.example.multitenancy.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import software.amazon.awssdk.services.apigateway.ApiGatewayClient;

@Service
@Transactional
public class ApigatewayService {

    @Autowired
    private ApiGatewayClient apiGatewayClient;

    @Value("${ApiName}")
    private String apiName;

    @Value("${RegionName}")
    private String regionName;

    public String getApigatewayBaseUrl() {
        return apiGatewayClient.getRestApis().items().stream()
            .filter(item -> Objects.equals(item.name(), apiName))
            .map(item -> item.id())
            .map(id -> "http://" + id + ".execute-api."+ regionName +".amazonaws.com")
            .findFirst()
            .orElse("");
    }
    
}
