package com.example.multitenancy.service;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.example.multitenancy.entity.CheckUsernamePasswordResult;
import com.example.multitenancy.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import software.amazon.awssdk.services.cognitoidentityprovider.CognitoIdentityProviderClient;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AdminInitiateAuthRequest;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AdminInitiateAuthResponse;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AuthFlowType;

@Service
@Transactional
public class CognitoService {

    @Autowired
    private CognitoIdentityProviderClient cognitoIdentityProviderClient;

    @Value("${cognitoUserPoolId}")
    private String userPoolId;

    @Value("${cognitoClientId}")
    private String cognitoClientId;

    @Value("${cognitoClientSecret}")
    private String cognitoClientSecret;

    public CheckUsernamePasswordResult performNoSrpAuthentication(User user) {
        CheckUsernamePasswordResult result = new CheckUsernamePasswordResult();
        try {
            Map<String, String> authParameters = new HashMap<>();
            authParameters.put("USERNAME", user.getUsername());
            authParameters.put("PASSWORD", user.getPassword());
            authParameters.put("SECRET_HASH", calculateSecretHash(cognitoClientId, cognitoClientSecret, user.getUsername()));
            AdminInitiateAuthRequest adminInitiateAuthRequest = AdminInitiateAuthRequest.builder()
                .authFlow(AuthFlowType.ADMIN_NO_SRP_AUTH)
                .clientId(cognitoClientId)
                .userPoolId(userPoolId)
                .authParameters(authParameters)
                .build();
            AdminInitiateAuthResponse adminInitiateAuth = cognitoIdentityProviderClient.adminInitiateAuth(adminInitiateAuthRequest);
            System.out.println(adminInitiateAuth);
            result.setResult(adminInitiateAuth);
            if (adminInitiateAuth.authenticationResult() != null) {
                result.setValidUsernamePassword(true);
            }
        } catch (Exception e) {  
            e.printStackTrace();
        }

        return result;
    }

    private String calculateSecretHash(String userPoolClientId, String userPoolClientSecret, String userName) {
        final String HMAC_SHA256_ALGORITHM = "HmacSHA256";

        SecretKeySpec signingKey = new SecretKeySpec(
                userPoolClientSecret.getBytes(StandardCharsets.UTF_8),
                HMAC_SHA256_ALGORITHM);
        try {
            Mac mac = Mac.getInstance(HMAC_SHA256_ALGORITHM);
            mac.init(signingKey);
            mac.update(userName.getBytes(StandardCharsets.UTF_8));
            byte[] rawHmac = mac.doFinal(userPoolClientId.getBytes(StandardCharsets.UTF_8));
            return java.util.Base64.getEncoder().encodeToString(rawHmac);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error while calculating ");
        }
    }
    
}
