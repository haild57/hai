package com.example.multitenancy.jsonb;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.multitenancy.util.ObjectMapperUtil;
import com.fasterxml.jackson.databind.JsonNode;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;
import org.postgresql.util.PGobject;
import org.springframework.stereotype.Component;

@Component
@MappedTypes(JsonNode.class)
public class JsonNodeTypeHandler extends BaseTypeHandler<JsonNode> {

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, JsonNode parameter, JdbcType jdbcType)
            throws SQLException {
        if (ps != null) {
            try {
                PGobject ext = new PGobject();
                ext.setType("jsonb");
                ext.setValue(ObjectMapperUtil.objectMapper.writeValueAsString(parameter));
                ps.setObject(i, ext);
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException();
            }
        }
    }

    @Override
    public JsonNode getNullableResult(ResultSet resultSet, String s) throws SQLException {
        try {
            return ObjectMapperUtil.objectMapper.readTree(resultSet.getString(s));
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @Override
    public JsonNode getNullableResult(ResultSet resultSet, int i) throws SQLException {
        try {
            return ObjectMapperUtil.objectMapper.readTree(resultSet.getString(i));
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    @Override
    public JsonNode getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        try {
            return ObjectMapperUtil.objectMapper.readTree(callableStatement.getString(i));
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

}
