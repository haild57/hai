package com.example.multitenancy.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import software.amazon.awssdk.services.cognitoidentityprovider.model.AdminInitiateAuthResponse;

@Getter 
@Setter 
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CheckUsernamePasswordResult implements Serializable {
    private static final long serialVersionUID = -4551953276601557391L;
    
    private boolean validUsernamePassword;
    private boolean needMfaCode;
    private String mfaCode;
    private AdminInitiateAuthResponse result;
}