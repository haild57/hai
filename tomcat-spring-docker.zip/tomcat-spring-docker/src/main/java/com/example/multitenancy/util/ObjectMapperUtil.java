package com.example.multitenancy.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectMapperUtil{
    public static ObjectMapper objectMapper = new ObjectMapper();
}