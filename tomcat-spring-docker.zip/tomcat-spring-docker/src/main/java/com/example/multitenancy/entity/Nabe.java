package com.example.multitenancy.entity;

import java.io.Serializable;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter 
@Setter 
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Nabe implements Serializable {
    private static final long serialVersionUID = -4551953276601557391L;
    
    private int id;
    private String value;
    private JsonNode data;
}