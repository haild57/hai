package com.example.multitenancy.multi_tenant;

public class TenantContext {
    public static final String DEFAULT_TENANT = "public"; 

    private static ThreadLocal<String>  currentTenant = new InheritableThreadLocal<>();

    public static String getCurrentTenant() {
        return currentTenant.get();
    }

    public static void setCurrentTenant(String tenant) {
        currentTenant.set(tenant);
    }

    public static void clear() {
        currentTenant.set(null);
    }
}
