package com.example.multitenancy.javasdk;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import software.amazon.awssdk.services.apigateway.ApiGatewayClient;
import software.amazon.awssdk.services.cognitoidentityprovider.CognitoIdentityProviderClient;
import software.amazon.awssdk.services.lambda.LambdaClient;
import software.amazon.awssdk.services.ses.SesClient;
import software.amazon.awssdk.services.sns.SnsClient;

@Component
public class SdkConfig {
    @Bean
    public CognitoIdentityProviderClient cognitoIdentityProviderClient(){
        return CognitoIdentityProviderClient.create();
    }

    @Bean
    public LambdaClient lambdaClient(){
        return LambdaClient.create();
    }

    @Bean
    public SnsClient snsClient(){
        return SnsClient.create();
    }

    @Bean
    public SesClient sesClient(){
        return SesClient.create();
    }

    @Bean
    public ApiGatewayClient apiGatewayClient(){
        return ApiGatewayClient.create();
    }
}
