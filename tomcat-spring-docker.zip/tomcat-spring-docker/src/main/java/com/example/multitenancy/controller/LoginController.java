package com.example.multitenancy.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.multitenancy.entity.CheckUsernamePasswordResult;
import com.example.multitenancy.entity.User;
import com.example.multitenancy.service.ApigatewayService;
import com.example.multitenancy.service.CognitoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.view.RedirectView;

import software.amazon.awssdk.services.cognitoidentityprovider.model.AuthenticationResultType;

@Controller
public class LoginController {  
    @Autowired
    private CognitoService cognitoService;

    @Autowired
    private ApigatewayService apigatewayService;

    @Value("${ApiStageName}")
    private String apiStageName;

    @GetMapping("/logon")
    public String loginStep1Get(ModelMap modelMap){      
        modelMap.addAttribute("logonPostUrl", "/" + apiStageName + "/logon");    
        return "logon";
    }

    @PostMapping("/logon")
    public RedirectView loginStep1Post(@ModelAttribute("user") User user, HttpServletResponse response, HttpServletRequest request){
        CheckUsernamePasswordResult initAuthResponse = cognitoService.performNoSrpAuthentication(user);
        System.out.println("api gateway base url : " + apigatewayService.getApigatewayBaseUrl());

        
        // if username and password is correct
        if(initAuthResponse.isValidUsernamePassword()  && !initAuthResponse.isNeedMfaCode()){
            AuthenticationResultType authenticationResult = initAuthResponse.getResult().authenticationResult();
            response.addCookie(new Cookie("accessToken", authenticationResult.accessToken()));
            response.addCookie(new Cookie("idToken", authenticationResult.idToken()));
            response.addCookie(new Cookie("refreshToken", authenticationResult.refreshToken()));
            return new RedirectView(apigatewayService.getApigatewayBaseUrl() + "/" + apiStageName + "/general");

        // if username or password isnt correct
        } else {
            return new RedirectView(apigatewayService.getApigatewayBaseUrl() + "/" + apiStageName + "/logon");
        }
    }

    @GetMapping("/general")
    public String general(ModelMap modelMap){    
        modelMap.addAttribute("serviceName", "General");    
        return "general";
    }

    @GetMapping("/general/page1")
    public String generalPage1(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "General");         
        return "general";
    }

    @GetMapping("/general/page1/a")
    public String generalPage1a(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "General");         
        return "general";
    }

    @GetMapping("/general/page1/a/b")
    public String generalPage1ab(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "General");         
        return "general";
    }

    @GetMapping("/general/page2")
    public String generalPage2(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "General");         
        return "general";
    }

    @GetMapping("/ribs")
    public String ribs(ModelMap modelMap){    
        modelMap.addAttribute("serviceName", "Ribs");    
        return "general";
    }

    @GetMapping("/ribs/page1")
    public String ribsPage1(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "Ribs");         
        return "general";
    }

    @GetMapping("/ribs/page1/a")
    public String ribsPage1a(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "Ribs");         
        return "general";
    }
    @GetMapping("/ribs/page1/a/b")
    public String ribsPage1ab(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "Ribs");         
        return "general";
    }

    @GetMapping("/ribs/page2")
    public String ribsPage2(ModelMap modelMap){
        modelMap.addAttribute("serviceName", "Ribs");         
        return "general";
    }
}
