package com.example.multitenancy;

import java.util.Arrays;
import java.util.List;

import com.example.multitenancy.entity.Input;
import com.example.multitenancy.entity.Output;
import com.example.multitenancy.entity.Input.InputBuilder;
import com.example.multitenancy.util.ObjectMapperUtil;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import software.amazon.awssdk.services.sfn.SfnClient;
import software.amazon.awssdk.services.sfn.model.SendTaskFailureRequest;
import software.amazon.awssdk.services.sfn.model.SendTaskSuccessRequest;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class DemoApplication implements CommandLineRunner {
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		String inputString = System.getenv("input");
		Input input = ObjectMapperUtil.objectMapper.readValue(inputString, Input.class);
		SfnClient sfnClient = SfnClient.create();
		String token = System.getenv("token");
		try {
			// bussiness logic ....
			//......
			//......
			//......
			//......

			if (input.isThrowErrorInContainer()){
				throw new Exception("error");
			}
			//send success
			List<Input> outputs1 = Arrays.asList(
				Input.builder().catchErrorInContainer(true).throwErrorInContainer(true).initInputForOtherBatch(false).build(),
				Input.builder().catchErrorInContainer(true).throwErrorInContainer(false).initInputForOtherBatch(false).build(),
				Input.builder().catchErrorInContainer(false).throwErrorInContainer(true).initInputForOtherBatch(false).build(),
				Input.builder().catchErrorInContainer(false).throwErrorInContainer(false).initInputForOtherBatch(false).build()
			);

			Output output2 = Output.builder().status("Success").data("abcxyz").build();
			String outputsString = "";
			if (input.isInitInputForOtherBatch()){
				 outputsString = ObjectMapperUtil.objectMapper.writeValueAsString(outputs1);
			} else{
				outputsString = ObjectMapperUtil.objectMapper.writeValueAsString(output2);
			}
			System.out.println(outputsString);
			SendTaskSuccessRequest sendTaskSuccessRequest = SendTaskSuccessRequest.builder()
				.taskToken(token)
				.output(outputsString)
				.build();
			sfnClient.sendTaskSuccess(sendTaskSuccessRequest);

		} catch (Exception e) {
			if (input.isCatchErrorInContainer()){
				
				//send failure
				SendTaskFailureRequest sendTaskFailureRequest = SendTaskFailureRequest.builder()
					.taskToken(token)
					.error("CustomError")
					.build();
				sfnClient.sendTaskFailure(sendTaskFailureRequest);

			} else {
				throw e;
			}
		}
	} 

}
